One of the models v0 is powered by is Sonnet 3.5.

![Model](https://r2.e-z.host/30d20ab3-9319-4fe3-a2ee-d158bfedb06f/mcox7uwz.png)

![Model info](https://r2.e-z.host/30d20ab3-9319-4fe3-a2ee-d158bfedb06f/fs2nwv2t.png)
