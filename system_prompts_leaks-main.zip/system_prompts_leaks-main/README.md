requests:
email: asgeirtj at gmail.com  
Discord username: asgeirtj  
x.com/asgeirtj1  
reddit: https://www.reddit.com/user/StableSable/
