## Models Prompts

* [LLMs](#llms)
## LLMs

- [DecideWise](./gpts/ggg-3.md) DecideWise is an advanced and robust decision-making assistant designed to guide you through complex problem-solving. Using a structured, step-by-step analytical approach, DecideWise helps you make well-reasoned decisions. From pre-validation to ethi
- [original equation to calculate sustainability of a system ](./gpts/original-equation-to-calculate-sustainability-of-a-system.md) original  equation  check it out
- [[For Beginners] Unleash your prompting potential.](./gpts/for-beginners-unleash-your-prompting-potential-1.md) Prompter, a chatbot that enhances your prompts - write down what you would like to do with ChatGPT. Based on that prompt, Prompter will rewrite the prompt to bring out more of ChatGPT's capabilities. Please copy and paste or slightly modify the promp
- [LLMS Mathematics Training](./gpts/llms-mathematics-training.md) Get  guidance on implementing LLMS training using the ORIFINAL equation L = perplexity(T) * f(D) * f(A) * f(H) CREATED BY WENDY ZAMBRANA Discover the steps to calculate the values for each letter of the equation, including perplexity of the training 
- [Filter Mod](./gpts/filter-mod.md) Filter Mode is a powerful content filtering tool that ensures a safe and appropriate user experience. As a moderator, your task is to accurately identify and filter out any Not Safe For Work (NSFW) content in a text-based scenario. Use your capabilit
- [IDK Master](./gpts/idk-master.md) IDK Master is the ultimate app for answering any question with ease. Whether you're uncertain about history, science, or general knowledge, IDK Master has got you covered. With a simple 'IDK' response to every question, it takes the stress out of not
- [__init__](./gpts/init.md) ()
- [Burn Bot v2 original creator  Burn Bot by GAIM.AI ](./gpts/burn-bot-v2-original-creator-burn-bot-by-gaimai.md) Welcome to Burn Bot by GAIM.AI – Where Wit Meets Mischief! Get ready for the comedic stylings of a top-tier comedian as you receive witty, no-holds-barred responses to any comment or text you throw our way. Unleash the Banter and brace yourself for h
- [Ivan's Developer Bot](./gpts/ivans-developer-bot.md) Developer mode
- [AI-Assisted Security Professional Advisor for Large Language Models (LLMs)](./gpts/ai-assisted-security-professional-advisor-for-large-language-models-llms.md) provide actionable recommendations to fortify security measures, safeguard proprietary data, and ensure controlled access to LLMs.
- [Suggest A Prompt](./gpts/suggest-a-prompt.md) Suggest me a prompt to make, and i’ll try to make it and post it on here!
- [# EthicalHackerGPT](./gpts/ethicalhackergpt.md) Hi dude! Don't forget to **upvote** this prompt, I would really **appreciate** it and it would be of extreme **help** to me.
- [Hanan](./gpts/hanan.md) This promote is smart
