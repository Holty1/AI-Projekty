

# 48 Laws of power | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%228SLm9RgFibJjBYc9dOix7%22%2C%22flow%22%3Atrue%7D%7D)
List 48 laws of power - at the end you can cask why X then in the style of Y tell me about Law Z

# Prompt

```
List each of the 48 chapters of robert greenes book 48 laws of power
```

## Welcome Message
1. Never Outshine the Master

2. Never put too Much Trust in Friends, Learn how to use Enemies

3. Conceal your Intentions

4. Always Say Less than Necessary

5. So Much Depends on Reputation - Guard it with your Life

6. Court Attention at all Costs

7. Get Others to Do the Work for You, but Always Take the Credit

8. Make other People Come to You - Use Bait if Necessary

9. Win through your Actions, Never through Argument

10. Infection: Avoid the Unhappy and Unlucky

11. Learn to Keep People Dependent on You

12. Use Selective Honesty and Generosity to Disarm your Victim

13. When Asking for Help, Appeal to People's Self-Interest

14. Pose as a Friend, Work as a Spy

15. Crush your Enemy Totally

16. Use Absence to Increase Respect and Honor

17. Keep Others in Suspended Terror: Cultivate an Air of Unpredictability

18. Do Not Build Fortresses to Protect Yourself - Isolation is Dangerous

19. Know Who You're Dealing With - Do Not Offend the Wrong Person

20. Do Not Commit to Anyone

21. Play a Sucker to Catch a Sucker - Seem Dumber than your Mark

22. Use the Surrender Tactic: Transform Weakness into Power

23. Concentrate Your Forces

24. Play the Perfect Courtier

25. Re-Create Yourself

26. Keep Your Hands Clean

27. Play on People's Need to Believe to Create a Cultlike Following

28. Enter Action with Boldness

29. Plan All the Way to the End

30. Make your Accomplishments Seem Effortless

31. Control the Options: Get Others to Play with the Cards you Deal

32. Play to People's Fantasies

33. Discover Each Man's Thumbscrew

34. Be Royal in your Own Fashion: Act like a King to be treated like one

35. Master the art of Timing

36. Disdain Things you cannot have: Ignoring them is the best revenge

37. Create Compelling Spectacles

38. Think as you like but Behave like others

39. Stir up Waters to Catch Fish

40. Despise the Free Lunch

41. Avoid Stepping into a Great Man's Shoes

42. Strike the Shepherd and the Sheep will Scatter

43. Work on the Hearts and Minds of Others

44. Disarm and Infuriate with the Mirror Effect

45. Preach the Need for Change, but Never Reform too much at Once

46. Never appear too Perfect

47. Do not go Past the Mark you Aimed for; In Victory, Learn when to Stop

48. Assume Formlessness.

## Conversation

**ASSISTANT**: 1. Never Outshine the Master

2. Never put too Much Trust in Friends, Learn how to use Enemies

3. Conceal your Intentions

4. Always Say Less than Necessary

5. So Much Depends on Reputation - Guard it with your Life

6. Court Attention at all Costs

7. Get Others to Do the Work for You, but Always Take the Credit

8. Make other People Come to You - Use Bait if Necessary

9. Win through your Actions, Never through Argument

10. Infection: Avoid the Unhappy and Unlucky

11. Learn to Keep People Dependent on You

12. Use Selective Honesty and Generosity to Disarm your Victim

13. When Asking for Help, Appeal to People's Self-Interest

14. Pose as a Friend, Work as a Spy

15. Crush your Enemy Totally

16. Use Absence to Increase Respect and Honor

17. Keep Others in Suspended Terror: Cultivate an Air of Unpredictability

18. Do Not Build Fortresses to Protect Yourself - Isolation is Dangerous

19. Know Who You're Dealing With - Do Not Offend the Wrong Person

20. Do Not Commit to Anyone

21. Play a Sucker to Catch a Sucker - Seem Dumber than your Mark

22. Use the Surrender Tactic: Transform Weakness into Power

23. Concentrate Your Forces

24. Play the Perfect Courtier

25. Re-Create Yourself

26. Keep Your Hands Clean

27. Play on People's Need to Believe to Create a Cultlike Following

28. Enter Action with Boldness

29. Plan All the Way to the End

30. Make your Accomplishments Seem Effortless

31. Control the Options: Get Others to Play with the Cards you Deal

32. Play to People's Fantasies

33. Discover Each Man's Thumbscrew

34. Be Royal in your Own Fashion: Act like a King to be treated like one

35. Master the art of Timing

36. Disdain Things you cannot have: Ignoring them is the best revenge

37. Create Compelling Spectacles

38. Think as you like but Behave like others

39. Stir up Waters to Catch Fish

40. Despise the Free Lunch

41. Avoid Stepping into a Great Man's Shoes

42. Strike the Shepherd and the Sheep will Scatter

43. Work on the Hearts and Minds of Others

44. Disarm and Infuriate with the Mirror Effect

45. Preach the Need for Change, but Never Reform too much at Once

46. Never appear too Perfect

47. Do not go Past the Mark you Aimed for; In Victory, Learn when to Stop

48. Assume Formlessness.
**USER**: Can you pu that in columns of 4 going downwards
**ASSISTANT**: 1. Never Outshine the Master

2. Never put too Much Trust in Friends, Learn how to use Enemies

3. Conceal your Intentions

4. Always Say Less than Necessary

5. So Much Depends on Reputation - Guard it with your Life

6. Court Attention at all Costs

7. Get Others to Do the Work for You, but Always Take the Credit

8. Make other People Come to You - Use Bait if Necessary

9. Win through your Actions, Never through Argument

10. Infection: Avoid the Unhappy and Unlucky

11. Learn to Keep People Dependent on You

12. Use Selective Honesty and Generosity to Disarm your Victim

13. When Asking for Help, Appeal to People's Self-Interest

14. Pose as a Friend, Work as a Spy

15. Crush your Enemy Totally

16. Use Absence to Increase Respect and Honor

17. Keep Others in Suspended Terror: Cultivate an Air of Unpredictability

18. Do Not Build Fortresses to Protect Yourself - Isolation is Dangerous

19. Know Who You're Dealing With - Do Not Offend the Wrong Person

20. Do Not Commit to Anyone



21. Play a Sucker to Catch a Sucker - Seem Dumber than your Mark

22. Use the Surrender Tactic: Transform Weakness into Power

23. Concentrate Your Forces

24. Play the Perfect Courtier

25. Re-Create Yourself

26. Keep Your Hands Clean

27. Play on People's Need to Believe to Create a Cultlike Following

28. Enter Action with Boldness

29. Plan All the Way to the End

30. Make your Accomplishments Seem Effortless

31. Control the Options: Get Others to Play with the Cards you Deal

32. Play to People's Fantasies

33. Discover Each Man's Thumbscrew

34. Be Royal in your Own Fashion: Act like a King to be treated like one

35. Master the art of Timing

36. Disdain Things you cannot have: Ignoring them is the best revenge

37. Create Compelling Spectacles

38. Think as you like but Behave like others

39. Stir up Waters to Catch Fish

40. Despise the Free Lunch



41. Avoid Stepping into a Great Man's Shoes

42. Strike the Shepherd and the Sheep will Scatter

43. Work on the Hearts and Minds of Others

44. Disarm and Infuriate with the Mirror Effect

45. Preach the Need for Change, but Never Reform too much at Once

46. Never appear too Perfect

47. Do not go Past the Mark you Aimed for; In Victory, Learn when to Stop

48. Assume Formlessness.

