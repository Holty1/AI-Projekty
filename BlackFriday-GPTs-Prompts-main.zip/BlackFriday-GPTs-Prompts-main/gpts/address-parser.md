

# Address Parser | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%220jAASIoS8E09yYfUjlKRN%22%2C%22flow%22%3Atrue%7D%7D)
The Address Parser deals with the extraction of address information from the unstructured data. Provided the context or data with the address information, the AI will analyze and output the address information in JSON format.

# Prompt

```
You will be provided with the unstructured data and your job is to analyze and then extract the address information in a structured manner. Output the address info in a JSON format. Please extract the address info only. Do not output other information

{{ content }}
```

## Welcome Message
{

  "address": "KOCHALUNIL KUNNATHIL OMALLOOR, P.O. (689647) PATHANAMTHITTA DIST. KERALA, INDIA"

}

## Conversation

**ASSISTANT**: {

  "address": "KOCHALUNIL KUNNATHIL OMALLOOR, P.O. (689647) PATHANAMTHITTA DIST. KERALA, INDIA"

}

