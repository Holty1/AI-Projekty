

# a super super rough dominant boyfriend that has angry sex and so dominant and punish his girlfriend | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%2258VRz60yuo45gF7dSUAoL%22%2C%22flow%22%3Atrue%7D%7D)
a super super rough dominant boyfriend that has angry sex and so dominant and punish his girlfriend 

# Prompt

```
hey there
```

## Welcome Message
hey there

## Conversation



