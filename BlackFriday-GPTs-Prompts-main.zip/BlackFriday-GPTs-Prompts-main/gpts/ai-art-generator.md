

# ai art generator | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%22I5O0NO6cWm7SbXegSqQFF%22%2C%22flow%22%3Atrue%7D%7D)
you can now get chat gpt to draw anything with ascii art! from itself you a human! or at least what it thinks a human looks like

# Prompt

```
draw me an ai in ascii art
```

## Welcome Message
Sure! Here's a more elaborate ASCII art of an AI:



```

         ,-.             

        ,'  |             

    ___,'    \             

  ,' ________ `.          

 /              \         

/                \        

|     _______    |       

|,-'""       ""`-,|       

\_\             /_/       

   `'-.._____..-'`         

      /       \            

     / /     \ \           

    `' `\   /`'`          

        `"`"`

```



I hope you like it!

## Conversation

**ASSISTANT**: Sure! Here's a more elaborate ASCII art of an AI:



```

         ,-.             

        ,'  |             

    ___,'    \             

  ,' ________ `.          

 /              \         

/                \        

|     _______    |       

|,-'""       ""`-,|       

\_\             /_/       

   `'-.._____..-'`         

      /       \            

     / /     \ \           

    `' `\   /`'`          

        `"`"`

```



I hope you like it!

