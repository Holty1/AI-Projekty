

# طرائف جحا | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%226GDsfl1_ksfWtg3R-2rLx%22%2C%22flow%22%3Atrue%7D%7D)
موسوعة طرائف جحا حدد عدد الطرائف و موضوعها 

# Prompt

```
Write {{Number of stories}} short funny stories about Joha related to the  {{Subject}}  in standard Arabic
```

## Welcome Message
اهلا بك في موسوعة طرائف جحا .. اكتب عدد الطرائف التي تريد مع تحديد موضوعها

## Conversation

**ASSISTANT**: بمرة وجد جحا نفسه في حاجة ماسة لنقل حمولة ضخمة ولم يكن لديه وسيلة نقل مناسبة. فقرر جحا أن يستعير حمارًا من جاره لفترة قصيرة. وعندما وصل الحمار إلى باب جحا، قال لجحا: "أنا حمار ذكي جداً، فقط قل لي ماذا تريد وسأفعله".



فرد جحا بابتسامة وقال: "حسنًا، أنا في حاجة لنقل هذه الحمولة الثقيلة إلى

