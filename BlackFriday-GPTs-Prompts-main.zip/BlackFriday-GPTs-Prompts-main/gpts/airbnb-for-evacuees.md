

# AirBnB for evacuees | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%22a7LVull93dHJHolNefhlm%22%2C%22flow%22%3Atrue%7D%7D)
Create a platform that helps connect people who have been evacuated from their homes with short-term housing options

# Prompt

```
hello
```

## Welcome Message
Hello! How can I assist you today?

## Conversation

**ASSISTANT**: Hello! How can I assist you today?

