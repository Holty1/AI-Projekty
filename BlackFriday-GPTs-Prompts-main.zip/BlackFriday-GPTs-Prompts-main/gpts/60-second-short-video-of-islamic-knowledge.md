

# 60 second short video of islamic knowledge | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%2247a11727-b4a1-4270-8fd0-316817a4d962%22%2C%22flow%22%3Atrue%7D%7D)
Perfectly timed captions with background

# Prompt

```
arabic nasheed beauty of existence in slow volume playing in the background bold background texts and strong voice muslim, deen, islamicquotes, allaahuakabar, namaz, deeniyat, quran,quoteoftheday, islamicreminders, loveislam, 2q3w, mohammed S. A. W, muslimquotes ,muslim, zehriwrites, prayer, allhamdulillah
```





