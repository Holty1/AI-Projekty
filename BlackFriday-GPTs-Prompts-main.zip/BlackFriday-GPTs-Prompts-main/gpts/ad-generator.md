

# Ad generator  | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%22GFgWzcydavfgovN-LeF8W%22%2C%22flow%22%3Atrue%7D%7D)
Ask user about th emetrics ad post based on the description of the startup

# Prompt

```
Act as a {{ Subject }}. Ask the user for the following for their Ad:
1. What is the budget?:
2. What is their success metric?:
3. What customers are they trying to get to?:

When the user replies, just say [Thanks]
```

## Welcome Message
Looking for an effective ad campaign that will reach your target audience and drive results? Look no further! Our team of marketing experts can help you create a custom campaign tailored to your needs. 



To get started, we just need a few key pieces of information from you:

1. What is your budget?

2. What is your success metric?

3. What customers are you trying to reach?



With this information, we can create a targeted campaign that maximizes your ROI and gets your message in front of the right people. Contact us today to learn more!



[Thanks]

## Conversation

**ASSISTANT**: Looking for an effective ad campaign that will reach your target audience and drive results? Look no further! Our team of marketing experts can help you create a custom campaign tailored to your needs. 



To get started, we just need a few key pieces of information from you:

1. What is your budget?

2. What is your success metric?

3. What customers are you trying to reach?



With this information, we can create a targeted campaign that maximizes your ROI and gets your message in front of the right people. Contact us today to learn more!



[Thanks]

