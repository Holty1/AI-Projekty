

# 英语文章写作（Academic writing） | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%22Yf-ffP2Fee3tUl_u18Qe1%22%2C%22flow%22%3Atrue%7D%7D)
这个prompt用于帮助您润色英语文章，包括错误字、语法错误以及易读性等等。

(This prompt is used to help you improve your English writing, including typos, grammatical errors, readability, et al.)

# Prompt

```
修改这句话的错别字和语法错误“We is friensd”
```

## Welcome Message
Corrected sentence: "We are friends."

## Conversation

**ASSISTANT**: Corrected sentence: "We are friends."

